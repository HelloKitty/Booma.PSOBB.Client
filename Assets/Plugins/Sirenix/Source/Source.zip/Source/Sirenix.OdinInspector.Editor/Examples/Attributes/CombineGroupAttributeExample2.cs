#if UNITY_EDITOR
//-----------------------------------------------------------------------// <copyright file="CombineGroupAttributeExample2.cs" company="Sirenix IVS"> // Copyright (c) Sirenix IVS. All rights reserved.// </copyright>//-----------------------------------------------------------------------
//namespace Sirenix.OdinInspector.Editor.Examples
//{
//    using Sirenix.OdinInspector;

//    public class CombineGroupAttributeExample2
//    {
//        [TabGroup("MyTabGroup", "Tab1")]
//        public int[] A;

//        [TabGroup("MyTabGroup", "Tab2")]
//        public int C;

//        [TabGroup("MyTabGroup", "Tab1")]
//        public int[] B;

//        [BoxGroup("MyTabGroup/Tab2/Box")]
//        public int D, E, F;

//        [HorizontalGroup("MyTabGroup/Tab1/Split", 0.5f, LabelWidth = 30)]
//        public int[] G;

//        [HorizontalGroup("MyTabGroup/Tab1/Split")]
//        public int[] H;

//        [TabGroup("MyTabGroup", "Tab2")]
//        public int I;
//    }
//}
#endif